# INST377 
Final Group Project: Collab for meeting App

Developers:
Anthony J. Aruldoss: anthonyaruldossjr@gmail.com
James Geleta: jimmygeleta13@gmail.com
Robert Barclay: rgbarc@gmail.com
Evan Joyce: ejoyce74@gmail.com
Hamdi Kamus: hamdikamus@gmail.com


This app is an attempt to resolve the problem of finding a common time to meet when doing group work.
Students face this problem almost every time a group project is started. No one knows when everyone is free 
and everyone is not always free. 

Therefore, this app allows a group leader and whoever takes the initiative to "sign up" and create a group 
account. They will create a group username, group password and add their email. With this group account, any of the 
group members can sign in. Upon signing in, group members are greeted with a quick and easy form that they 
can complete. This form comes complete with form validation to make sure users are filling in information. 
In addition, the forms check group information in the data base to make sure group names and group usernames
actually exist. 

//

Upon downloading the zip file you have all and the only files needed for this web application to work.
For configuration to your specific server you will need to go to >>/fpR2/includes/dhb.inc.php
This file is how you will fill in host name, database username, database password, and name of database.
NOTICE: the SQL database needed is in included in the fpR2 zip file. This database comes with sample data
to let you see how things are supposed to look and work within the database. 

//

Enjoy!