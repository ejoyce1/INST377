<!DOCTYPE html>
<html lang="en">
<!--	
        <body>
            <nav>
                <ul>
                    <li> <a href="index.php"> Home </a> </li>
                </ul>
                <div>
                    <form action="includes/login.inc.php" method="post">
<input type="text" name="username" placeholder="username">
<input type="password" name="pwd" placeholder="password">
<button type="submit" name="login-submit"> Login </button>
                    </form>
<a href="signup.php">Sign Up</a>
<form action="includes/logout.inc.php" method="post">
<button type="submit" name="logout-submit"> Logout </button>
                    </form>
                </div>
            </nav>
        </body>
</html>-->
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>COLLAB</title>
	<link rel="stylesheet" type="text/css" href="collabmeet.css">
	<meta name= "description" contents= "collabmeet_username">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!--Fonts-->
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">

</head>
<body class="main_body">
	<div  class="jumbotron" id="collab_title">
		<h1>COLLAB</h1>
            
        
</body>
</html>